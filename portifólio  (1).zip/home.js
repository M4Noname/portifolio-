function toggleMenu() {
  var menu = document.querySelector('.menu');
  menu.classList.toggle('active');
}